#include <Arduino.h>
#include <Servo.h>
#include <SoftwareSerial.h>

//ESP
SoftwareSerial arduinoSerial(10, 11); //RX, TX

//RFID
//SG90
#define rainservoPIN 5
Servo myRainservo;

//L298
//PUMP
//LED
//BUTTON
//FAN
//BUZZER


void setup() {
  Serial.begin(9600);
  arduinoSerial.begin(9600); //giao tiep esp qua tx,rx0

  //SG90
  myRainservo.attach(rainservoPIN);
  myRainservo.write(0); //gian phoi mac dinh

  Serial.println("Arduino san sang nhan du lieu...");
}

void RAIN_CONTROL() {
  if (arduinoSerial.available()) {
    int rainState = arduinoSerial.parseInt(); //nhan du lieu tu esp
    Serial.print("Arduino - Gia tri mua nhan duoc: ");
    Serial.println(rainState);

    if (rainState == 0) {    //Co mua
      myRainservo.write(90); //Dong gian phoi
      Serial.println("Co mua - Servo 90° - Gian phoi dong");
    }
    else {
      myRainservo.write(0); //Mo gian phoi
      Serial.println("Khong mua - Servo 0° - Gian phoi mo");
    }
  }
}

void loop() {
  RAIN_CONTROL();  
}
